import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AboutPage() {
  return (
    <main className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">About Us</h1>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div>
            <p className="text-lg mb-4">
              Founded in Dubai, our company has been providing premium services since 2015. We pride ourselves on
              excellence, reliability, and customer satisfaction.
            </p>
            <p className="text-lg mb-4">
              Our team of professionals is dedicated to delivering the highest quality service to our clients, ensuring
              that every experience exceeds expectations.
            </p>
            <p className="text-lg mb-6">
              We combine local expertise with international standards to create unique experiences tailored to your
              needs.
            </p>
            <Button asChild className="bg-amber-500 hover:bg-amber-600">
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
          <div className="relative h-[300px] rounded-lg overflow-hidden">
            <Image
              src="/placeholder.svg?height=600&width=800&text=About+Us+Image"
              alt="About our company"
              fill
              className="object-cover"
            />
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Our Values</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {[
              { title: "Excellence", description: "We strive for excellence in everything we do" },
              { title: "Integrity", description: "We operate with honesty and transparency" },
              { title: "Innovation", description: "We continuously improve our services" },
            ].map((value, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                <p>{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6">Our Team</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((member) => (
              <div key={member} className="text-center">
                <div className="relative w-40 h-40 mx-auto mb-4 rounded-full overflow-hidden">
                  <Image
                    src={`/placeholder.svg?height=160&width=160&text=Team+Member+${member}`}
                    alt={`Team member ${member}`}
                    fill
                    className="object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold">Team Member {member}</h3>
                <p className="text-gray-600">Position</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}

