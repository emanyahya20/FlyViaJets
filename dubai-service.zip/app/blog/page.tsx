import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

const blogPosts = [
  {
    id: 1,
    title: "Top 10 Attractions in Dubai",
    excerpt: "Discover the most amazing places to visit in Dubai, from the Burj Khalifa to the Palm Jumeirah.",
    date: "March 15, 2023",
    category: "Travel",
    image: "/placeholder.svg?height=400&width=600&text=Blog+Post+1",
  },
  {
    id: 2,
    title: "Dubai's Best Kept Secrets",
    excerpt:
      "Beyond the glitz and glamour, Dubai has hidden gems that locals love. Here's our guide to the city's best kept secrets.",
    date: "February 28, 2023",
    category: "Lifestyle",
    image: "/placeholder.svg?height=400&width=600&text=Blog+Post+2",
  },
  {
    id: 3,
    title: "Business Opportunities in Dubai",
    excerpt:
      "Dubai offers numerous opportunities for entrepreneurs and businesses. Learn about the advantages of setting up in Dubai.",
    date: "January 20, 2023",
    category: "Business",
    image: "/placeholder.svg?height=400&width=600&text=Blog+Post+3",
  },
  {
    id: 4,
    title: "Dubai's Culinary Scene",
    excerpt:
      "From traditional Emirati cuisine to international fine dining, Dubai's food scene has something for everyone.",
    date: "December 10, 2022",
    category: "Food",
    image: "/placeholder.svg?height=400&width=600&text=Blog+Post+4",
  },
]

export default function BlogPage() {
  return (
    <main className="container mx-auto px-4 py-16">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold">Our Blog</h1>
          <div className="flex gap-2">
            <Button variant="outline">All</Button>
            <Button variant="outline">Travel</Button>
            <Button variant="outline">Business</Button>
            <Button variant="outline">Lifestyle</Button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {blogPosts.map((post) => (
            <article key={post.id} className="bg-white rounded-lg overflow-hidden shadow-md">
              <div className="relative h-48">
                <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-2">
                  <span>{post.date}</span>
                  <span className="mx-2">•</span>
                  <span>{post.category}</span>
                </div>
                <h2 className="text-xl font-bold mb-2">{post.title}</h2>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <Button asChild variant="link" className="p-0 h-auto text-amber-500 hover:text-amber-600">
                  <Link href={`/blog/${post.id}`}>Read More</Link>
                </Button>
              </div>
            </article>
          ))}
        </div>

        <div className="flex justify-center">
          <Button variant="outline">Load More</Button>
        </div>
      </div>
    </main>
  )
}

