import Link from "next/link"
import { Button } from "@/components/ui/button"
import AboutSection from "@/components/about-section"
import ContactSection from "@/components/contact-section"
import BlogSection from "@/components/blog-section"
import InstagramFeed from "@/components/instagram-feed"
import FleetSection from "@/components/fleet-section"
import { Instagram } from "lucide-react"

export default function Home() {
  return (
    <main className="relative">
      {/* Hero Section with Video Background */}
      <section className="relative h-screen flex items-center">
        <div className="absolute inset-0 w-full h-full overflow-hidden z-0">
          <video autoPlay muted loop className="absolute min-w-full min-h-full object-cover">
            {/* Replace with actual plane takeoff video */}
            <source src="/videos/plane-takeoff.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <div className="absolute inset-0 bg-black/40" />
        </div>

        <div className="relative z-10 container mx-auto px-4 md:px-8 lg:px-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Discover the Future of Flying Private
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-2xl">
              Redefining luxury and corporate private jet charter with exceptional service and professionalism
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 text-white rounded-md px-8">
                <Link href="#contact">Contact Us</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-red-600 text-red-600 hover:bg-red-600/10 rounded-md px-8"
              >
                <Link href="#about">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Fleet/Services Section */}
      <section id="fleet" className="py-20 bg-white">
        <FleetSection />
      </section>

      {/* About Us Section */}
      <section id="about" className="py-20 bg-gray-100">
        <AboutSection />
      </section>

      {/* Blog Section */}
      <section id="blog" className="py-20 bg-white">
        <BlogSection />
      </section>

      {/* Instagram Feed Section */}
      <section id="instagram" className="py-20 bg-gray-100">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold">Follow Us on Instagram</h2>
            <Link href="https://instagram.com/flyviajets" className="flex items-center text-red-600 hover:text-red-700">
              <Instagram className="mr-2" />
              <span>@flyviajets</span>
            </Link>
          </div>
          <InstagramFeed />
        </div>
      </section>

      {/* Contact Us Section */}
      <section id="contact" className="py-20 bg-gray-900 text-white">
        <ContactSection />
      </section>
    </main>
  )
}

