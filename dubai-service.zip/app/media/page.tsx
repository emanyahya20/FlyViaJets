import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"
import { Play } from "lucide-react"

export default function MediaPage() {
  return (
    <main className="container mx-auto px-4 py-16">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Media</h1>

        <Tabs defaultValue="photos" className="mb-12">
          <TabsList className="mb-8">
            <TabsTrigger value="photos">Photos</TabsTrigger>
            <TabsTrigger value="videos">Videos</TabsTrigger>
            <TabsTrigger value="press">Press Releases</TabsTrigger>
          </TabsList>

          <TabsContent value="photos">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map((photo) => (
                <div key={photo} className="relative aspect-square rounded-lg overflow-hidden">
                  <Image
                    src={`/placeholder.svg?height=400&width=400&text=Photo+${photo}`}
                    alt={`Photo ${photo}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="videos">
            <div className="grid md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((video) => (
                <div key={video} className="group relative aspect-video rounded-lg overflow-hidden bg-gray-200">
                  <Image
                    src={`/placeholder.svg?height=300&width=500&text=Video+${video}+Thumbnail`}
                    alt={`Video ${video}`}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white/80 rounded-full p-3 group-hover:bg-amber-500 transition-colors">
                      <Play className="w-8 h-8 text-amber-500 group-hover:text-white" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="press">
            <div className="space-y-6">
              {[
                { title: "Company Launches New Service in Dubai", date: "April 10, 2023" },
                { title: "Partnership Announcement with Dubai Tourism", date: "March 5, 2023" },
                { title: "Company Receives Excellence Award", date: "February 15, 2023" },
                { title: "Expansion Plans Announced for 2023", date: "January 20, 2023" },
              ].map((press, index) => (
                <div key={index} className="border-b pb-6">
                  <div className="text-sm text-gray-500 mb-2">{press.date}</div>
                  <h3 className="text-xl font-bold mb-2">{press.title}</h3>
                  <p className="text-gray-600 mb-4">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua.
                  </p>
                  <button className="text-amber-500 hover:text-amber-600 font-medium">Read Full Press Release</button>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}

