import Image from "next/image"

export default function AboutSection() {
  return (
    <div className="container mx-auto px-4 md:px-8 lg:px-16">
      <div className="max-w-3xl mx-auto text-center mb-16">
        <h2 className="text-3xl font-bold mb-4">About Us</h2>
        <p className="text-lg text-gray-600">
          We are a premium private jet charter service based in Dubai, committed to excellence and customer
          satisfaction.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
        <div className="order-2 md:order-1">
          <h3 className="text-2xl font-bold mb-6">Excellence in Every Flight</h3>
          <p className="text-lg mb-6 text-gray-700">
            Founded in Dubai, our company has been providing premium private jet charter services since 2015. We pride
            ourselves on excellence, reliability, and customer satisfaction.
          </p>
          <p className="text-lg mb-6 text-gray-700">
            Our team of aviation professionals is dedicated to delivering the highest quality service to our clients,
            ensuring that every flight exceeds expectations.
          </p>
          <div className="grid grid-cols-2 gap-6 mt-8">
            <div className="flex flex-col">
              <span className="text-3xl font-bold text-red-600">15+</span>
              <span className="text-gray-600">Years Experience</span>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-bold text-red-600">500+</span>
              <span className="text-gray-600">Satisfied Clients</span>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-bold text-red-600">24/7</span>
              <span className="text-gray-600">Customer Support</span>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-bold text-red-600">100%</span>
              <span className="text-gray-600">Client Satisfaction</span>
            </div>
          </div>
        </div>
        <div className="order-1 md:order-2 relative h-[400px] rounded-lg overflow-hidden shadow-xl">
          <Image
            src="/placeholder.svg?height=800&width=600&text=Luxury+Jet+Interior"
            alt="Luxury private jet interior"
            fill
            className="object-cover"
          />
        </div>
      </div>

      <div className="mt-24">
        <h3 className="text-2xl font-bold text-center mb-12">Why Choose Us</h3>
        <div className="grid sm:grid-cols-3 gap-8">
          {[
            {
              title: "Premium Fleet",
              description: "Access to a diverse fleet of meticulously maintained private jets for any travel need.",
              image: "/placeholder.svg?height=300&width=300&text=Premium+Fleet",
            },
            {
              title: "Experienced Crew",
              description: "Our highly trained pilots and cabin crew ensure a safe and luxurious flying experience.",
              image: "/placeholder.svg?height=300&width=300&text=Experienced+Crew",
            },
            {
              title: "Personalized Service",
              description: "Tailored flight experiences with attention to every detail of your journey.",
              image: "/placeholder.svg?height=300&width=300&text=Personalized+Service",
            },
          ].map((value, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-lg text-center shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="relative h-40 w-40 mx-auto mb-6 rounded-full overflow-hidden">
                <Image src={value.image || "/placeholder.svg"} alt={value.title} fill className="object-cover" />
              </div>
              <h4 className="text-xl font-bold mb-3">{value.title}</h4>
              <p className="text-gray-600">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

