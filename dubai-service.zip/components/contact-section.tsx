import { MapPin, Phone, Mail, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ContactSection() {
  return (
    <div className="container mx-auto px-4 md:px-8 lg:px-16">
      <div className="max-w-3xl mx-auto text-center mb-16">
        <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
        <p className="text-lg text-gray-300">We'd love to hear from you. Get in touch with our team.</p>
      </div>

      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <div className="space-y-8">
              <div className="flex items-start">
                <MapPin className="w-6 h-6 text-red-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold text-lg text-white">Address</h3>
                  <p className="text-gray-300">
                    Sheikh Zayed Road
                    <br />
                    Downtown Dubai
                    <br />
                    Dubai, United Arab Emirates
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <Phone className="w-6 h-6 text-red-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold text-lg text-white">Phone</h3>
                  <p className="text-gray-300">+971 4 123 4567</p>
                </div>
              </div>

              <div className="flex items-start">
                <Mail className="w-6 h-6 text-red-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold text-lg text-white">Email</h3>
                  <p className="text-gray-300">info@flyviajets.com</p>
                </div>
              </div>

              <div className="flex items-start">
                <Clock className="w-6 h-6 text-red-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold text-lg text-white">Business Hours</h3>
                  <p className="text-gray-300">
                    Monday - Friday: 9:00 AM - 6:00 PM
                    <br />
                    Saturday: 10:00 AM - 4:00 PM
                    <br />
                    Sunday: Closed
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12">
              <Button asChild className="bg-red-600 hover:bg-red-700 text-white rounded-md px-8 py-6 text-lg">
                <Link href="tel:+97141234567">
                  <Phone className="mr-2 h-5 w-5" /> Call Now
                </Link>
              </Button>
            </div>
          </div>

          <div className="rounded-lg overflow-hidden h-[400px] relative">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.9932118442395!2d55.2708426!3d25.2048493!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43348a67e24b%3A0xff45e502e1ceb7e2!2sSheikh%20Zayed%20Rd%20-%20Dubai!5e0!3m2!1sen!2sae!4v1648226618021!5m2!1sen!2sae"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Dubai Office Location"
              className="absolute inset-0"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

