"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      alert("Message sent! We'll get back to you soon.")
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name" className="text-gray-900">
          Full Name
        </Label>
        <Input id="name" placeholder="John Doe" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="email" className="text-gray-900">
          Email
        </Label>
        <Input id="email" type="email" placeholder="john@example.com" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone" className="text-gray-900">
          Phone Number
        </Label>
        <Input id="phone" placeholder="+971 50 123 4567" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="subject" className="text-gray-900">
          Subject
        </Label>
        <Input id="subject" placeholder="How can we help you?" required />
      </div>

      <div className="space-y-2">
        <Label htmlFor="message" className="text-gray-900">
          Message
        </Label>
        <Textarea
          id="message"
          placeholder="Please provide details about your inquiry..."
          className="min-h-[120px]"
          required
        />
      </div>

      <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600" disabled={isSubmitting}>
        {isSubmitting ? "Sending..." : "Send Message"}
      </Button>
    </form>
  )
}

