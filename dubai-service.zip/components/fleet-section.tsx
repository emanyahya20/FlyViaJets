import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const jets = [
  {
    id: 1,
    title: "Light Jets",
    description: "Perfect for short trips with 4-6 passengers, offering comfort and efficiency for regional travel.",
    image: "/placeholder.svg?height=400&width=600&text=Light+Jet",
    features: ["4-6 Passengers", "Range: 1,500 miles", "Luggage: 55 cubic ft"],
  },
  {
    id: 2,
    title: "Mid-Size Jets",
    description: "Ideal for longer journeys with 6-8 passengers, providing additional space and amenities.",
    image: "/placeholder.svg?height=400&width=600&text=Mid-Size+Jet",
    features: ["6-8 Passengers", "Range: 2,500 miles", "Luggage: 75 cubic ft"],
  },
  {
    id: 3,
    title: "Heavy Jets",
    description: "Designed for long-haul flights with 8-14 passengers, offering premium comfort and luxury.",
    image: "/placeholder.svg?height=400&width=600&text=Heavy+Jet",
    features: ["8-14 Passengers", "Range: 4,000+ miles", "Luggage: 100+ cubic ft"],
  },
]

export default function FleetSection() {
  return (
    <div className="container mx-auto px-4 md:px-8 lg:px-16">
      <div className="max-w-3xl mx-auto text-center mb-16">
        <h2 className="text-3xl font-bold mb-4">Our Private Jet Fleet</h2>
        <p className="text-lg text-gray-600">
          Discover our range of exclusive private jets designed to exceed your expectations
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {jets.map((jet) => (
          <div key={jet.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
            <div className="relative h-48">
              <Image src={jet.image || "/placeholder.svg"} alt={jet.title} fill className="object-cover" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-3">{jet.title}</h3>
              <p className="text-gray-600 mb-4">{jet.description}</p>
              <ul className="mb-6 space-y-2">
                {jet.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <span className="text-red-600 mr-2">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Button asChild className="w-full bg-red-600 hover:bg-red-700 text-white">
                <Link href="#contact">Request a Quote</Link>
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-16 text-center">
        <p className="text-lg text-gray-600 mb-6">
          Can't find what you're looking for? We offer a wide range of aircraft to suit your specific needs.
        </p>
        <Button asChild className="bg-red-600 hover:bg-red-700 text-white px-8">
          <Link href="#contact">View All Aircraft</Link>
        </Button>
      </div>
    </div>
  )
}

