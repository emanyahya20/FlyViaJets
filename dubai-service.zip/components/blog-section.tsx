import Link from "next/link"
import Image from "next/image"
import { ArrowRight } from "lucide-react"

const blogPosts = [
  {
    id: 1,
    title: "The Benefits of Private Jet Travel",
    excerpt: "Discover why more executives and luxury travelers are choosing private jets for their travel needs.",
    date: "March 15, 2023",
    category: "Travel",
    image: "/placeholder.svg?height=400&width=600&text=Private+Jet+Benefits",
  },
  {
    id: 2,
    title: "Top Private Jet Destinations in 2023",
    excerpt: "Explore the most exclusive and sought-after destinations accessible by private jet this year.",
    date: "February 28, 2023",
    category: "Destinations",
    image: "/placeholder.svg?height=400&width=600&text=Jet+Destinations",
  },
  {
    id: 3,
    title: "Private Aviation: Sustainability Initiatives",
    excerpt: "Learn about the latest sustainability efforts in private aviation and how the industry is evolving.",
    date: "January 20, 2023",
    category: "Industry",
    image: "/placeholder.svg?height=400&width=600&text=Aviation+Sustainability",
  },
]

export default function BlogSection() {
  return (
    <div className="container mx-auto px-4 md:px-8 lg:px-16">
      <div className="flex justify-between items-center mb-12">
        <h2 className="text-3xl font-bold">Latest News & Articles</h2>
        <Link href="#" className="text-red-600 hover:text-red-700 flex items-center">
          View All <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {blogPosts.map((post) => (
          <article
            key={post.id}
            className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="relative h-48">
              <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
              <div className="absolute top-4 left-4 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                {post.category}
              </div>
            </div>
            <div className="p-6">
              <div className="text-sm text-gray-500 mb-2">{post.date}</div>
              <h3 className="text-xl font-bold mb-2">{post.title}</h3>
              <p className="text-gray-600 mb-4">{post.excerpt}</p>
              <Link href="#" className="text-red-600 hover:text-red-700 font-medium inline-flex items-center">
                Read More <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

