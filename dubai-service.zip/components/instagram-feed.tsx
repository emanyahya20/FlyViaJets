"use client"

import { useState, useEffect } from "react"
import Image from "next/image"

// Mock Instagram posts for flyviajets with jet images
const mockInstagramPosts = [
  {
    id: "1",
    imageUrl: "/placeholder.svg?height=600&width=600&text=Private+Jet+1",
    caption: "Our newest addition to the fleet #PrivateJet #LuxuryTravel #flyviajets",
    likes: 245,
    comments: 18,
    timestamp: "2 days ago",
  },
  {
    id: "2",
    imageUrl: "/placeholder.svg?height=600&width=600&text=Jet+Interior",
    caption: "Luxury interiors for a comfortable journey #JetInterior #Comfort #flyviajets",
    likes: 312,
    comments: 24,
    timestamp: "4 days ago",
  },
  {
    id: "3",
    imageUrl: "/placeholder.svg?height=600&width=600&text=Jet+Takeoff",
    caption: "Taking off to new destinations #JetLife #Aviation #flyviajets",
    likes: 189,
    comments: 32,
    timestamp: "1 week ago",
  },
  {
    id: "4",
    imageUrl: "/placeholder.svg?height=600&width=600&text=Jet+Sunset",
    caption: "Sunset views from 40,000 feet #SkyViews #LuxuryTravel #flyviajets",
    likes: 276,
    comments: 15,
    timestamp: "1 week ago",
  },
  {
    id: "5",
    imageUrl: "/placeholder.svg?height=600&width=600&text=VIP+Service",
    caption: "VIP service for our distinguished clients #VIPExperience #PrivateAviation #flyviajets",
    likes: 198,
    comments: 21,
    timestamp: "2 weeks ago",
  },
  {
    id: "6",
    imageUrl: "/placeholder.svg?height=600&width=600&text=Jet+Cockpit",
    caption: "Behind the scenes in the cockpit #PilotLife #Aviation #flyviajets",
    likes: 221,
    comments: 9,
    timestamp: "2 weeks ago",
  },
]

export default function InstagramFeed() {
  const [posts, setPosts] = useState(mockInstagramPosts)
  const [loading, setLoading] = useState(true)

  // Simulate loading Instagram feed
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[1, 2, 3, 4, 5, 6].map((item) => (
          <div key={item} className="aspect-square bg-gray-200 animate-pulse rounded-lg"></div>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {posts.map((post) => (
        <div key={post.id} className="group relative aspect-square rounded-lg overflow-hidden">
          <Image
            src={post.imageUrl || "/placeholder.svg"}
            alt={post.caption}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
            <p className="text-white text-sm line-clamp-2 mb-2">{post.caption}</p>
            <div className="flex items-center text-white text-xs">
              <span className="mr-3">❤️ {post.likes}</span>
              <span>💬 {post.comments}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

